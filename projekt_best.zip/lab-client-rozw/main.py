import multiprocessing
import threading
from multiprocessing import Queue

from typing import List
from fastapi import FastAPI
from pydantic import BaseModel
import requests
import logging

app = FastAPI()

logging.basicConfig(handlers=[
    logging.StreamHandler()
],
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.DEBUG)

global Help
Help = {
    'HUM_MIN': 0,
    'HUM_MAX': 1,
    'HUM_MEAN': 2,
    'TEMP_MIN': 3,
    'TEMP_MAX': 4,
    'TEMP_MEAN': 5,
    'LIGHT_MIN': 6,
    'LIGHT_MAX': 7,
    'LIGHT_MEAN': 8,
    'PRESS_MIN': 9,
    'PRESS_MAX': 10,
    'PRESS_MEAN': 11,
    'PREC_MIN': 12,
    'PREC_MAX': 13,
    'PREC_MEAN': 14,
}


class SensorDataEntry(BaseModel):
    data_type: str
    day: int
    val: float


class Handshake(BaseModel):
    ip_addr: str
    port: int


SERVER_IP = 'localhost'
SERVER_PORT = 5678

CLIENT_IP = 'localhost'
CLIENT_PORT = 6780

INDEKS = 11

def function(queue : Queue):
    result = multiprocessing.Array('d', [0] * 500000) # w przypadku duzej liczby danych powinno być zwiększane!
    day_readings = multiprocessing.Array('i', [0] * 500)

    lock = multiprocessing.Lock()
    lockday = multiprocessing.Lock()
    lockMean = multiprocessing.Lock()
    lockMin = multiprocessing.Lock()
    lockMax = multiprocessing.Lock()

    days = multiprocessing.Array('d', [0] * 500)

    DATA_TYPES = ['HUM', 'TEMP', 'LIGHT', 'PRESS', 'PREC']

    n_workers = 2 # uruchamiamy 3 wątki wykonujące process / liczbę wątków możesz zmieniać wg potrzeb

    workers = [multiprocessing.Process(target=process, args=(queue, lock, result, days, day_readings, lockday, lockMax, lockMin, lockMean ))
               for i in range(n_workers)]

    for w in workers:
        w.start()

    for w in workers:
        w.join()

    wynik = []

    ddays = 0
    for i in range(0,len(days)):
        if(days[i] == 1):
            ddays = i
        else:
            break

    for dzien in range(0, ddays+1):
        for type in DATA_TYPES:
            result[Help.get(type + '_MEAN') + dzien * len(Help)] /= (day_readings[dzien] / len(DATA_TYPES))

    # wypisanie wyniku w formie w której serwer jej oczekuje
    # process zapisuje dane w tabeli pod indeksami po 20 indeksów na dzień w kolejności jak poniżej
    # ponieważ tak jest najbardziej wydajnie
    for dd in range(0, ddays+1):
        dzien = {'day': dd,
                    'HUM_MIN': result[dd * len(Help) + Help.get('HUM_MIN')],
                    'HUM_MAX': result[dd * len(Help) + Help.get('HUM_MAX')],
                     'HUM_MEAN': result[dd * len(Help) + Help.get('HUM_MEAN')],
                     'TEMP_MIN': result[dd * len(Help) + Help.get('TEMP_MIN')],
                     'TEMP_MAX': result[dd * len(Help) + Help.get('TEMP_MAX')],
                     'TEMP_MEAN': result[dd * len(Help) + Help.get('TEMP_MEAN')],
                     'LIGHT_MIN': result[dd * len(Help) + Help.get('LIGHT_MIN')],
                     'LIGHT_MAX': result[dd * len(Help) + Help.get('LIGHT_MAX')],
                     'LIGHT_MEAN': result[dd * len(Help) + Help.get('LIGHT_MEAN')],
                     'PRESS_MIN': result[dd * len(Help) + Help.get('PRESS_MIN')],
                     'PRESS_MAX': result[dd * len(Help) + Help.get('PRESS_MAX')],
                     'PRESS_MEAN': result[dd * len(Help) + Help.get('PRESS_MEAN')],
                     'PREC_MIN': result[dd * len(Help) + Help.get('PREC_MIN')],
                     'PREC_MAX': result[dd * len(Help) + Help.get('PREC_MAX')],
                     'PREC_MEAN': result[dd * len(Help) + Help.get('PREC_MEAN')]}
        wynik.append(dzien)

    requests.post(f"http://{SERVER_IP}:{SERVER_PORT}/results",
                  json={"ip_addr": CLIENT_IP, "port": CLIENT_PORT, "indeks": INDEKS, "aggregates": wynik})


def process(queue: Queue, lock:multiprocessing.Lock(), result : multiprocessing.Array, days:multiprocessing.Queue, day_readings : multiprocessing.Array,
            lockday:multiprocessing.Lock(), lockMax:multiprocessing.Lock(), lockMin:multiprocessing.Lock(), lockMean:multiprocessing.Lock() ):
    while True:
        # logging.info(f'{dataCounter.value} + {multiprocessing.current_process()}')
        # każdy wątek pobiera z kolejki aż skończą się dane
        lock.acquire()
        if queue.empty():
            lock.release()
            break
        data = queue.get()
        lock.release()
        lockday.acquire()
        day_readings[data.day] = day_readings[data.day] + 1

        if days[data.day] == 0:
            days[data.day] = 1
            DATA_TYPES = ['HUM', 'TEMP', 'LIGHT', 'PRESS', 'PREC']
            for type in DATA_TYPES:
                result[Help.get(type + '_MIN') + data.day * len(Help)] = 21
        lockday.release()
        lockMin.acquire()
        if data.val < result[Help.get(data.data_type + '_MIN') + data.day * len(Help)]:
            result[Help.get(data.data_type + '_MIN') + data.day*len(Help)] = data.val
        lockMin.release()
        lockMax.acquire()
        if data.val > result[Help.get(data.data_type + '_MAX') + data.day * len(Help)]:
            result[Help.get(data.data_type + '_MAX') + data.day*len(Help)] = data.val
        lockMax.release()
        lockMean.acquire()
        result[Help.get(data.data_type + '_MEAN') + data.day * len(Help)] += data.val
        lockMean.release()
    return result

@app.post("/sensor-data", status_code=201)
async def create_sensor_data(sensor_data_entry: List[SensorDataEntry]):
    queue = multiprocessing.Queue()
    for el in sensor_data_entry:
        queue.put(el)
    logging.info('Processing')
    res = threading.Thread(target=function, args=(queue,), daemon=True)
    res.start()

@app.get("/hello")
async def say_hello():
    res = requests.post(f"http://{SERVER_IP}:{SERVER_PORT}/clients/handshake",
                        json={"ip_addr": CLIENT_IP, "port": CLIENT_PORT, "indeks": INDEKS})
    if (res.status_code == 201):
        return "Success"
    else:
        return f"Error occurred {res.text}"
